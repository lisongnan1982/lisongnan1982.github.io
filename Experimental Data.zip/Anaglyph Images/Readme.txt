Left up: Color anaglyph (Photoshop anaglyph)
Left down: LAB anaglyph [1]
Right up: XYZ anaglyph [2]
Right down: the proposed method [3]




[1].D.F. McAllister, Y. Zhou, and S. Sullivan, ��Methods for computing color anaglyphs��, Stereoscopic Displays and Applications XXI, vol. 7524, 2010.
[2].E. Dubois, ��A projection method to generate anaglyph stereo images��, IEEE International Conference on Acoustics, Speech, and Signal Processing, vol. 3, pp. 1661-1664, 2001.
[3]. Songnan Li, Li Ma, King Ngi Ngan, "Anaglyph Image Generation by Matching Color Appearance Attributes" (submitted)