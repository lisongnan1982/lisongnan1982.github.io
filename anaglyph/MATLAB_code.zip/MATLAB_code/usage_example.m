% Read images
leftImg = imread('shrimp_left.jpg');
rightImg = imread('shrimp_right.jpg');

% Generate anaglyph image
anaImg = MCAA(leftImg,rightImg);

% Show image
imshow(anaImg);