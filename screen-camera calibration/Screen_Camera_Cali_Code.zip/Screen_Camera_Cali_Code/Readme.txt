1. To try the code, press the ENTER key. Default values of the screen width, height, camera intrinsic parameters will be used.

2. To use this code for your application, you need to use a ruler to get the width and height of your screen first. You also need to get the camera��s intrinsic parameters using toolbox like:
http://www.vision.caltech.edu/bouguetj/calib_doc/

3. Put your images in the subfolders accordingly. Don��t change the subfolder��s name.

4. If you use Kinect, notice that the captured images should be flipped horizontally before the calibration.

Please feel free to change the code to suite your application. For example, you can add camera distortion correction if necessary. You are welcome to report any corrections via snli@ee.cuhk.edu.hk. I will be glad to answer your questions related to this code.


